var searchData=
[
  ['x',['x',['../structroyale__depth__point.html#a0ad893a4bb2f9990496cbbf20ca4b9df',1,'royale_depth_point::x()'],['../struct_royale_dot_net_1_1_depth_point.html#a1dadb0cf404f625fd18129fecc4ae539',1,'RoyaleDotNet.DepthPoint.x()'],['../structroyale_1_1_depth_point.html#a1399d86a36855e0759aa44c613d70018',1,'royale::DepthPoint::x()']]],
  ['xyzcpoints',['xyzcPoints',['../structroyale__sparse__point__cloud.html#ad349e883b912b164044738819e8f1f88',1,'royale_sparse_point_cloud::xyzcPoints()'],['../struct_royale_dot_net_1_1_sparse_point_cloud.html#a010df1ea0abab83a9446042446e9dbfe',1,'RoyaleDotNet.SparsePointCloud.xyzcPoints()'],['../structroyale_1_1_sparse_point_cloud.html#ab74f5b574bff10856f5dd58fa763665b',1,'royale::SparsePointCloud::xyzcPoints()']]]
];
