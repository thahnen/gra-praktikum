var searchData=
[
  ['triggermode',['TriggerMode',['../namespace_royale_dot_net.html#a3a6ddffbca905ff66a24060b3858d50e',1,'RoyaleDotNet.TriggerMode()'],['../namespaceroyale.html#a789748ed808cd6ff9d366c4ad060e45f',1,'royale::TriggerMode()']]]
];
