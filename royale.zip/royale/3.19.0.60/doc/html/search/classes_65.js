var searchData=
[
  ['enable_5fif',['enable_if',['../structroyale_1_1iterator_1_1enable__if.html',1,'royale::iterator']]],
  ['enable_5fif_3c_20true_2c_20t_20_3e',['enable_if&lt; true, T &gt;',['../structroyale_1_1iterator_1_1enable__if_3_01true_00_01_t_01_4.html',1,'royale::iterator']]],
  ['event',['Event',['../class_royale_dot_net_1_1_event.html',1,'RoyaleDotNet']]],
  ['exposurelimits',['ExposureLimits',['../class_royale_dot_net_1_1_exposure_limits.html',1,'RoyaleDotNet']]],
  ['extendeddata',['ExtendedData',['../class_royale_dot_net_1_1_extended_data.html',1,'RoyaleDotNet']]]
];
